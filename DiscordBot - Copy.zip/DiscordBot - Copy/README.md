# discord_bot_tutorial
### Have fun with Discord Bot : )

[Reference](https://hackmd.io/@Ev0n9YKlTzCKhedHrgZ2zw/Sy9ux3b_9)

[Music Bot executables download](https://drive.google.com/drive/folders/1saBzH-jajJuDgn2_d_Ts_Yf-RtNj6aZa?usp=sharing)

