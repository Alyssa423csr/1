import discord
from discord.ext import commands
import json 
from core import Cog_Extension

class TodoList(Cog_Extension):
    # Initialization 
    def __init__(self, bot):
        self.todo = []
        self.bot = bot

     

    # Add todolist 
    # item 是要增加的待辨事項
    @commands.command()
    async def AddTodoList(self, ctx, item):
        self.todo.append(item)
        await ctx.send(f"新增代辦事項:{item}")

        # 用 append 將新代辦事項加入

     


    # Remove todolist
    # item 是要移除的待辨事項
    @commands.command()
    async def RemoveTodoList(self, ctx, item):
        if item in self.todo:
            self.todo.remove(item)
            await ctx.send(f"移除代辦事項:{item}")
        else:
            await ctx.send(f"清單中找不到:{item}")

        # 用 remove 刪除項目
        # 若刪除的 item 在事項中--->傳刪除某 item 
        # 若刪除的 item 未在清單中-->傳清單中找不到 item

          

    # Sort todolist
    @commands.command()
    async def SortTodoList(self, ctx):
        
        self.todo.sort()
        # 將代辦事項清單 self.todo 進行排列
        sortedlist = "\n".join(self.todo) 
        # 將 self.todo 列表中的所有元素換行接起來
        await ctx.send(f"已排序:\n{sortedlist}")
        # 回傳"已排序"和排序後的內容


    # Clear todolist
    @commands.command()
    async def ClearTodoList(self, ctx):
       
        self.todo.clear()
        # 用clear的方式清除所有代辦事項
        await ctx.send("已清除")
        # 回傳"已清除"


async def setup(bot):
    await bot.add_cog(TodoList(bot))
