import discord
from discord.ext import commands
import random

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix='$', intents=intents)

class GuessNumber(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.target_number = None
        self.max_guesses = 5
        self.guess_time = 0

    @commands.command()
    async def play(self, ctx):
        await ctx.send("start")
        await ctx.send("歡迎來到猜數字遊戲！")
        await ctx.send("請輸入數字範圍")
        self.guess_time = 0

    @commands.command()
    async def value(self, ctx, minNum: int, maxNum: int):
        min_num = int(minNum)
        max_num = int(maxNum)
        self.target_number = random.randint(min_num, max_num)
        await ctx.send(f"數字範圍為 {min_num}~{max_num}")
        await ctx.send(f"目標數字已設置 (for debugging): {self.target_number}")

    @commands.command()
    async def guess(self, ctx, guess: int):
        if self.target_number is None:
            await ctx.send("請先設定數字範圍使用$value <minNum> <maxNum>.")
            return

        guess = int(guess)
        self.guess_time += 1

        if guess > self.target_number:
            await ctx.send("太大了！請繼續猜一個數字")
        elif guess < self.target_number:
            await ctx.send("太小了！請繼續猜一個數字")
        else:
            await ctx.send("恭喜！你猜對了")
            self.guess_time = 0
            self.target_number = None  # Reset the target number for a new game
            return

        if self.guess_time == self.max_guesses:
            await ctx.send(f"很可惜，你未能猜對。正確答案是 {self.target_number}")
            self.guess_time = 0
            self.target_number = None  # Reset the target number for a new game

async def setup(bot):
    await bot.add_cog(GuessNumber(bot))

