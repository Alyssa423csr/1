import discord
from discord.ext import commands
import os  
from dotenv import load_dotenv

load_dotenv()
bot = commands.Bot(command_prefix ="$", intents = discord.Intents.all())

@bot.event
async def on_ready():
    for FileName in os.listdir('./cmds'):
        if FileName.endswith('.py'):
            await bot.load_extension(f'cmds.{FileName[:-3]}')
    
    print(">>Bot is Online<<")

@bot.command()
async def load(ctx, extension):
    await bot.load_extension(f'cmds.{extension}')
    await ctx.send(f'Loaded')

@bot.command()
async def reload(ctx, extension):
    await bot.reload_extension(f'cmds.{extension}')
    await ctx.send(f'Reloaded')

@bot.command()
async def unload(ctx, extension):
    await bot.unload_extension(f'cmds.{extension}')
    await ctx.send(f'Unloaded')

if  __name__ == "__main__":
    bot.run(os.getenv('TOKEN'))




import discord
from discord.ext import commands
import json
import os

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix ="$", intents = discord.Intents.all())


# Initialize the todo list file if it doesn't exist
if not os.path.exists('data.json'):
    with open('data.json', 'w') as f:
        json.dump([], f)

def load_todos():
    with open('data.json', 'r') as f:
        return json.load(f)

def save_todos(todos):
    with open('data.json', 'w') as f:
        json.dump(todos, f)

@bot.event
async def on_ready():
    print(f'Bot is ready as {bot.user}')

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        await ctx.send("命令未找到，請檢查命令名稱。")
    else:
        raise error

@bot.command(name='$AddTodoList')
async def add_todo_list(ctx, *, item):
    todos = load_todos()
    todos.append({'item': item, 'author': ctx.author.name})
    save_todos(todos)
    await ctx.send(embed=discord.Embed(title="待辦事項新增", description=f"已新增: {item}", color=0x00ff00))

@bot.command(name='$RemoveTodoList')
async def remove_todo_list(ctx, *, item):
    todos = load_todos()
    removed_item = None
    for todo in todos:
        if todo['item'].lower() == item.lower():
            removed_item = todo
            todos.remove(todo)
            break
    if removed_item:
        save_todos(todos)
        await ctx.send(embed=discord.Embed(title="待辦事項刪除", description=f"已刪除: {removed_item['item']}", color=0xff0000))
    else:
        await ctx.send(embed=discord.Embed(title="錯誤", description="此待辦事項不存在", color=0xff0000))

@bot.command(name='$ClearTodoList')
async def clear_todo_list(ctx):
    save_todos([])
    await ctx.send(embed=discord.Embed(title="清空待辦事項", description="所有待辦事項已清空", color=0xff0000))

@bot.command(name='$ShowTodoList')
async def show_todo_list(ctx, sort_by: str = "index"):
    todos = load_todos()
    if sort_by == "index":
        sorted_todos = list(enumerate(todos))
    elif sort_by == "author":
        sorted_todos = sorted(enumerate(todos), key=lambda x: x[1]['author'])
    elif sort_by == "item":
        sorted_todos = sorted(enumerate(todos), key=lambda x: x[1]['item'])
    else:
        await ctx.send("無效的排序方式")
        return

    embed = discord.Embed(title="待辦事項列表", color=0x0000ff)
    for i, todo in sorted_todos:
        embed.add_field(name=f"{i}. {todo['item']}", value=f"作者: {todo['author']}", inline=False)
    await ctx.send(embed=embed)

# 啟動機器人
bot.run('MTIzODg2MzkxNTQwOTA4MDMzMQ.G9N-pF.a7DV96YIehO61tnhTgVa8AJhKk9TgPEaHZIWQ0')

